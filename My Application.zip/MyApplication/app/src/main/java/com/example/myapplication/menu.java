package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class menu extends AppCompatActivity {

    private Button btn_ph;
    private Button btn_f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btn_ph = findViewById(R.id.phrases);
        btn_f = findViewById(R.id.facts);
        Intent i_ph = new Intent(this, phrases.class);
        Intent i_f = new Intent(this, MainActivity2.class);

        btn_ph.setOnClickListener(v -> {
            startActivity(i_ph);
        });

        btn_f.setOnClickListener(v -> {
            startActivity(i_f);
        });
    }
}