package com.example.myapplication;

import com.google.firebase.firestore.auth.User;

import org.json.JSONException;
import org.json.JSONObject;

public class JsonParser {
    public User getUser(String response) throws JSONException {
        JSONObject userJson = new JSONObject(response);
        String name = userJson.getString("name");

        return null;
    }
}
